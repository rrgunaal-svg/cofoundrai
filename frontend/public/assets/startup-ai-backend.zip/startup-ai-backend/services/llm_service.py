import time

from services.mcp.providers.gemini import ask_gemini
from services.mcp.providers.groq import ask_groq

from services.mcp.metrics import record
from services.mcp.logger import log_event


def ask_llm(prompt: str) -> str:

    # ---------- GEMINI PRIMARY ----------
    start = time.time()

    try:
        response = ask_gemini(prompt)

        latency = time.time() - start

        record("gemini", True, latency)
        log_event("gemini", "success", latency)

        return response

    except Exception as e:

        latency = time.time() - start

        record("gemini", False, latency)
        log_event("gemini", "failure", latency, str(e))

        print("Gemini failed → Switching to Groq")

    # ---------- GROQ FALLBACK ----------
    start = time.time()

    try:
        response = ask_groq(prompt)

        latency = time.time() - start

        record("groq", True, latency)
        log_event("groq", "success", latency)

        return response

    except Exception as e:

        latency = time.time() - start

        record("groq", False, latency)
        log_event("groq", "failure", latency, str(e))

        raise Exception("All LLM providers failed")