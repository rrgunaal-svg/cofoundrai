from services.linkedin_post import generate_linkedin_post
from services.image_generator import save_startup_brochure
from orchestrator.agent_manager import run_all_agents
from services.mcp.providers.linkedin_mcp import prepare_linkedin_post


def auto_linkedin_post(data: dict):

    try:
        print("STEP 1: Running agents")
        analysis = run_all_agents(data)

        print("STEP 2: Generating LinkedIn post")
        post_text = generate_linkedin_post({
            "idea": data["idea"],
            "analysis": analysis
        })

        print("STEP 3: Generating brochure image")
        image_file = save_startup_brochure({
            "idea": data["idea"],
            "analysis": analysis
        })

        print("STEP 4: Preparing LinkedIn MCP")
        linkedin_data = prepare_linkedin_post(
            post_text,
            image_file
        )

        print("STEP 5: Done")

        return {
            "post_text": post_text,
            "analysis": analysis,
            "image_file": image_file,
            "linkedin_data": linkedin_data
        }

    except Exception as e:
        print("ERROR:", e)
        return {"error": str(e)}