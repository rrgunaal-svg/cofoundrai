from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os
import textwrap
import re

WIDTH = 1080
HEIGHT = 1080
PADDING = 100
LOGO_PATH = "logo.png"


# ------------------------------
# Background Gradient
# ------------------------------
def draw_gradient_background():
    img = Image.new("RGB", (WIDTH, HEIGHT), "#14001f")
    draw = ImageDraw.Draw(img)

    for y in range(HEIGHT):
        r = int(40 + (120 - 40) * (y / HEIGHT))
        g = int(0 + (30 - 0) * (y / HEIGHT))
        b = int(70 + (170 - 70) * (y / HEIGHT))
        draw.line([(0, y), (WIDTH, y)], fill=(r, g, b))

    return img


# ------------------------------
# Logo Glow Effect
# ------------------------------
def add_logo_with_glow(img):
    if not os.path.exists(LOGO_PATH):
        return 0

    logo = Image.open(LOGO_PATH).convert("RGBA")
    logo.thumbnail((260, 260))

    x = (WIDTH - logo.width) // 2
    y = 60

    # Glow layer
    glow = logo.copy()
    glow = glow.filter(ImageFilter.GaussianBlur(15))

    glow_layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    glow_layer.paste(glow, (x, y), glow)
    img.paste(glow_layer, (0, 0), glow_layer)

    # Original logo on top
    img.paste(logo, (x, y), logo)

    return y + logo.height + 50


# ------------------------------
# Extract Market Size
# ------------------------------
def extract_market_size(text):
    pattern = r'(\$?\s?\d+(\.\d+)?\s?(B|billion|M|million))'
    match = re.search(pattern, text)
    if match:
        return match.group(1)
    return None


# ------------------------------
# Gradient Text
# ------------------------------
def draw_gradient_text(base_img, position, text, font):
    gradient = Image.new("RGBA", (800, 150), (0, 0, 0, 0))
    draw = ImageDraw.Draw(gradient)

    for i in range(800):
        r = int(255 - (100 * i / 800))
        g = int(80 - (60 * i / 800))
        b = int(200 + (30 * i / 800))
        draw.line([(i, 0), (i, 150)], fill=(r, g, b, 255))

    text_mask = Image.new("L", (800, 150))
    mask_draw = ImageDraw.Draw(text_mask)
    mask_draw.text((0, 20), text, font=font, fill=255)

    gradient.putalpha(text_mask)

    base_img.paste(gradient, position, gradient)


# ------------------------------
# Wrapped Text Layout
# ------------------------------
def draw_wrapped_text(draw, text, font, y_position, fill):
    lines = textwrap.wrap(text, width=42)

    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        height = bbox[3] - bbox[1]

        draw.text((PADDING, y_position), line, font=font, fill=fill)
        y_position += height + 12

    return y_position


# ------------------------------
# Main Function
# ------------------------------
def save_startup_brochure(data: dict):
    idea = data.get("idea", "")
    analysis = data.get("analysis", {})

    validation = analysis.get("idea_validation", "")
    market = analysis.get("market_analysis", "")
    risk = analysis.get("risk_analysis", "")

    if not os.path.exists("images"):
        os.makedirs("images")

    filename = "images/linkedin_startup_post.png"

    img = draw_gradient_background()
    draw = ImageDraw.Draw(img)

    title_font = ImageFont.truetype("arial.ttf", 62)
    body_font = ImageFont.truetype("arial.ttf", 38)
    highlight_font = ImageFont.truetype("arial.ttf", 70)

    # Logo with Glow
    y = add_logo_with_glow(img)

    # Title
    y = draw_wrapped_text(draw, f"🚀 {idea}", title_font, y, "white")
    y += 30

    # Validation
    y = draw_wrapped_text(draw, f"Validation: {validation}", body_font, y, "#e1bee7")
    y += 30

    # Market
    market_size = extract_market_size(market)

    if market_size:
        draw.text((PADDING, y), "Targeting a", font=body_font, fill="white")
        y += 60

        draw_gradient_text(img, (PADDING, y), market_size, highlight_font)
        y += 100

    y = draw_wrapped_text(draw, market, body_font, y, "#d1c4e9")
    y += 30

    # Risk
    y = draw_wrapped_text(draw, f"Risk Strategy: {risk}", body_font, y, "#c5cae9")

    # Footer
    footer = "Validation → Architecture → Execution Blueprint"
    draw.text((PADDING, HEIGHT - 120), footer, font=body_font, fill="#eeeeee")

    img.save(filename)

    return filename