from services.llm_service import ask_llm


def generate_linkedin_post(data: dict):

    idea = data.get("idea","")

    prompt = f"""
Write a LinkedIn post about building an AI startup agent.

Startup idea:
{idea}

Style:

I Built My Own AI Agent!

Still can’t believe I created my own AI agent...

Short inspiring LinkedIn post.
"""

    return ask_llm(prompt)