import matplotlib.pyplot as plt
import os
import random


def generate_market_chart():

    labels = ["Early Startups","Growth Startups","Corporates"]
    values = [random.randint(20,40),
              random.randint(30,50),
              random.randint(10,30)]

    plt.figure()
    plt.pie(values, labels=labels, autopct='%1.1f%%')
    plt.title("Target Customer Distribution")

    path = "reports/market_chart.png"
    plt.savefig(path)
    plt.close()

    return path


def generate_risk_chart():

    categories = ["Technical","Financial","Market","Legal","Operational"]
    values = [random.randint(10,30) for _ in categories]

    plt.figure()
    plt.bar(categories, values)
    plt.title("Risk Distribution")
    plt.xticks(rotation=45)

    path = "reports/risk_chart.png"
    plt.tight_layout()
    plt.savefig(path)
    plt.close()

    return path