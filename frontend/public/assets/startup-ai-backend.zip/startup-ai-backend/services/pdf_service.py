from reportlab.platypus import Image, Paragraph, Spacer, PageBreak
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.colors import white
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER
from services.chart_generator import generate_market_chart, generate_risk_chart

import random
import os
import datetime
import uuid


LOGO_PATH = "logo.png"

# -------- GRADIENT COLORS --------
gradients = [
    ((0.145, 0.388, 0.922), (0.486, 0.227, 0.929)),  # Blue-Purple
    ((0.1,0.2,0.8),(0.6,0.2,0.9)),
    ((0.0,0.6,0.7),(0.0,0.2,0.4)),
    ((0.9,0.4,0.2),(0.6,0.1,0.2)),
    ((0.2,0.7,0.4),(0.0,0.3,0.2)),
    ((0.6,0.3,0.9),(0.3,0.1,0.5))
]


# -------- FIRST PAGE DESIGN --------
def first_page(canvas, doc):

    width, height = A4
    c1, c2 = random.choice(gradients)

    # -------- Abstract Mesh Gradient --------
    steps = 200
    for i in range(steps):
        ratio = i / steps
        r = c1[0] + (c2[0] - c1[0]) * ratio
        g = c1[1] + (c2[1] - c1[1]) * ratio
        b = c1[2] + (c2[2] - c1[2]) * ratio

        canvas.setFillColorRGB(r, g, b)
        canvas.rect(-width * 0.3 + (i * width / steps), 0, width, height, stroke=0, fill=1)

    # Glow effect
    canvas.saveState()
    canvas.setFillAlpha(0.05)
    for radius in range(400, 0, -10):
        canvas.setFillColorRGB(c2[0], c2[1], c2[2])
        canvas.circle(width * 0.8, height * 0.75, radius, stroke=0, fill=1)
    canvas.restoreState()

    center_x = width / 2

    # -------- TOP SECTION --------
    top_y = height - 160

    if os.path.exists(LOGO_PATH):
        canvas.drawImage(LOGO_PATH, center_x - 60, top_y, width=120, height=120, mask='auto')

    canvas.setFillColor(white)
    canvas.setFont("Helvetica-Bold", 24)
    canvas.drawCentredString(center_x, top_y - 40, "AI STARTUP COFOUNDER AGENT - MCP")

    # -------- CLIENT IDEA (AUTO WRAP) --------
    styles = getSampleStyleSheet()

    idea_style = ParagraphStyle(
        'IdeaStyle',
        parent=styles['Normal'],
        fontName="Helvetica",
        fontSize=16,
        textColor=white,
        alignment=TA_CENTER,
        leading=22
    )

    idea_paragraph = Paragraph(doc.client_idea, idea_style)

    w, h = idea_paragraph.wrap(width - 100, height)
    idea_paragraph.drawOn(canvas, 50, height/2 - h/2)

    # -------- FOOTER INFO --------
    canvas.setFont("Helvetica", 11)
    canvas.drawCentredString(center_x, 100, f"Date: {doc.generated_date}")
    canvas.drawCentredString(center_x, 80, f"Version: {doc.version}")
    canvas.drawCentredString(center_x, 60, f"Report ID: {doc.report_id}")
    canvas.drawCentredString(center_x, 40, "Generated using AI Cofounder Agent")


# -------- OTHER PAGES --------
def later_pages(canvas, doc):

    width, height = A4

    if os.path.exists(LOGO_PATH):
        canvas.drawImage(LOGO_PATH, 40, height - 60, width=60, height=60, mask='auto')

    # Watermark
    if os.path.exists(LOGO_PATH):
        canvas.saveState()
        canvas.translate(width/2, height/2)
        canvas.setFillAlpha(0.05)
        canvas.drawImage(LOGO_PATH, -200, -200, width=400, height=400, mask='auto')
        canvas.restoreState()

    canvas.setFont("Helvetica", 9)
    canvas.drawCentredString(width/2, 20, "AI Startup Cofounder Agent - MCP | Confidential Report")

    page_num = canvas.getPageNumber()
    canvas.drawRightString(width - 40, 20, f"Page {page_num}")


# -------- MAIN PDF GENERATOR --------
def generate_pdf(data):

    if not os.path.exists("reports"):
        os.makedirs("reports")

    filename = "reports/startup_report.pdf"

    styles = getSampleStyleSheet()

    normal_style = ParagraphStyle(
        'NormalText',
        parent=styles['Normal'],
        leading=16,
        spaceAfter=12
    )

    doc = SimpleDocTemplate(
        filename,
        pagesize=A4,
        rightMargin=40,
        leftMargin=40,
        topMargin=80,
        bottomMargin=60
    )

    # -------- Dynamic Metadata --------
    doc.client_idea = data.get("client_idea", "AI SaaS Platform for Chronic Disease Prediction")
    doc.generated_date = datetime.datetime.now().strftime("%B %d, %Y")
    doc.version = data.get("version", "1.0")
    doc.report_id = str(uuid.uuid4())[:8].upper()

    elements = []

    elements.append(Spacer(1, inch * 5))
    elements.append(PageBreak())

    def section(title, text):
        elements.append(Paragraph(title, styles['Heading1']))
        elements.append(Spacer(1, 10))
        elements.append(Paragraph(text.replace("\n", "<br/>"), normal_style))
        elements.append(PageBreak())

    section("Idea Validation", data.get("idea_validation", ""))
    section("Market Analysis", data.get("market_analysis", ""))

    market_chart = generate_market_chart()
    elements.append(Image(market_chart, width=400, height=300))
    elements.append(PageBreak())

    section("Risk Analysis", data.get("risk_analysis", ""))

    risk_chart = generate_risk_chart()
    elements.append(Image(risk_chart, width=400, height=300))
    elements.append(PageBreak())

    section("Business Strategy", data.get("business_strategy", ""))
    section("Technical Architecture", data.get("tech_stack", ""))

    doc.build(
        elements,
        onFirstPage=first_page,
        onLaterPages=later_pages
    )

    return filename
    