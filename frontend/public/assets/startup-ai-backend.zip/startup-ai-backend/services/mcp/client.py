# services/mcp/client.py

import time
from services.mcp.router import get_fallback_chain
from services.mcp.schemas import MCPResponse
from services.mcp.logger import log_event
from services.mcp.metrics import record


def request(prompt: str, capability: str = "analysis") -> MCPResponse:
    providers = get_fallback_chain(capability)

    for provider in providers:
        start = time.time()

        try:
            if provider == "gemini":
                from services.mcp.providers.gemini import call_gemini
                result = call_gemini(prompt)

            elif provider == "groq":
                from services.mcp.providers.groq import call_groq
                result = call_groq(prompt)

            elif provider == "claude":
                from services.mcp.providers.claude import call_claude
                result = call_claude(prompt)

            latency = time.time() - start

            log_event(provider, "success", latency)
            record(provider, True, latency)

            return MCPResponse(
                success=True,
                provider=provider,
                content=result
            )

        except Exception as e:
            latency = time.time() - start

            log_event(provider, "failure", latency, str(e))
            record(provider, False, latency)

            continue  # fallback to next provider

    return MCPResponse(
        success=False,
        provider="none",
        error="All MCP providers failed"
    )
