from services.mcp.providers.gemini import generate_gemini
from services.mcp.providers.groq import generate_groq


def generate(prompt: str, model="gemini"):

    if model == "gemini":

        try:
            return generate_gemini(prompt)

        except Exception as e:

            print("Gemini failed → Switching to Groq")

            return generate_groq(prompt)

    if model == "groq":

        return generate_groq(prompt)