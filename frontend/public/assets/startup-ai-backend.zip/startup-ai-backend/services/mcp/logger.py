# services/mcp/logger.py

from datetime import datetime

def log_event(provider: str, status: str, latency: float, error: str = None):
    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    message = (
        f"[{timestamp}] provider={provider} "
        f"status={status} latency={latency:.2f}s"
    )

    if error:
        message += f" error={error}"

    print(message)
