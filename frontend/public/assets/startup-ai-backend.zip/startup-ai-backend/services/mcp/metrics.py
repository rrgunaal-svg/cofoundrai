# services/mcp/metrics.py

metrics = {
    "total_requests": 0,
    "success_count": 0,
    "failure_count": 0,
    "provider_usage": {
        "gemini": 0,
        "groq": 0,
        "claude": 0,
    },
    "total_latency": 0.0,
}

def record(provider: str, success: bool, latency: float):
    metrics["total_requests"] += 1
    metrics["total_latency"] += latency

    if success:
        metrics["success_count"] += 1
        metrics["provider_usage"][provider] += 1
    else:
        metrics["failure_count"] += 1

def average_latency() -> float:
    if metrics["total_requests"] == 0:
        return 0.0
    return metrics["total_latency"] / metrics["total_requests"]
