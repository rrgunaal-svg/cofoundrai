from dataclasses import dataclass
from typing import Optional

@dataclass
class MCPResponse:
    success: bool
    provider: str
    content: Optional[str] = None
    error: Optional[str] = None
