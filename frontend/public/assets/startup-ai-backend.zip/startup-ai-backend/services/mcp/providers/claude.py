def call_claude(prompt: str) -> str:
    raise RuntimeError("Claude not configured")
