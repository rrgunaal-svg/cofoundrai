import time

# Supported Gemini models
GEMINI_MODELS = [
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-2.5-flash-lite",
    "gemini-2.0-flash-lite",
]

# Runtime latency memory
model_latency = {m: 9999 for m in GEMINI_MODELS}


def get_fastest_models():
    """
    Returns models sorted by observed latency
    """
    return sorted(GEMINI_MODELS, key=lambda m: model_latency[m])


def update_latency(model: str, latency: float):
    """
    Exponential moving average latency update
    """
    old = model_latency.get(model, latency)

    model_latency[model] = (old * 0.7) + (latency * 0.3)