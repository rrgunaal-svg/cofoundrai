from google import genai
import os
import time

from services.mcp.providers.model_router import (
    get_fastest_models,
    update_latency,
)


def ask_gemini(prompt: str):

    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        raise Exception("GEMINI_API_KEY not set")

    client = genai.Client(
        api_key=api_key,
        http_options={"api_version": "v1"}
    )

    last_error = None

    # 🔥 Try fastest models first
    for model_name in get_fastest_models():

        try:
            print(f"⚡ Testing model: {model_name}")

            start = time.time()

            response = client.models.generate_content(
                model=model_name,
                contents=prompt
            )

            latency = time.time() - start

            update_latency(model_name, latency)

            print(
                f"✅ {model_name} success "
                f"({latency:.2f}s)"
            )

            return response.text.strip()

        except Exception as e:
            last_error = str(e)

            print(f"❌ {model_name} failed")

            continue

    raise Exception(f"All Gemini models failed → {last_error}")