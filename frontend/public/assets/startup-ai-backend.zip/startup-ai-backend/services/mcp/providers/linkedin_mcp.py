def prepare_linkedin_post(text, image_path):

    return {
        "text": text,
        "image": image_path
    }