# services/mcp/metrics_api.py

from services.mcp.metrics import metrics, average_latency

def get_metrics():
    return {
        "total_requests": metrics["total_requests"],
        "success_count": metrics["success_count"],
        "failure_count": metrics["failure_count"],
        "provider_usage": metrics["provider_usage"],
        "average_latency": round(average_latency(), 3),
    }
