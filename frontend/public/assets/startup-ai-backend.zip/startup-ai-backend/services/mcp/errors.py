class MCPError(Exception):
    pass

class ProviderError(MCPError):
    pass
