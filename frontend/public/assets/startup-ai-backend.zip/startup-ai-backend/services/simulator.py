from services.llm_service import ask_llm


def run_simulation(data: dict):

    idea = data.get("idea", "")
    scenario = data.get("scenario", "")

    prompt = f"""
You are a startup simulation AI.

Startup Idea:
{idea}

Scenario:
{scenario}

Explain what would happen to the startup.

Return a clear explanation.
"""

    result = ask_llm(prompt)

    return {
        "simulation_result": result
    }