import requests

def upload_image_to_imgur(image_path):

    CLIENT_ID = "YOUR_IMGUR_CLIENT_ID"

    headers = {
        "Authorization": f"Client-ID {CLIENT_ID}"
    }

    with open(image_path, "rb") as f:

        response = requests.post(
            "https://api.imgur.com/3/image",
            headers=headers,
            files={"image": f}
        )

    return response.json()["data"]["link"]