from dotenv import load_dotenv
load_dotenv()  # ✅ MUST BE FIRST

from fastapi import FastAPI
from routers.routes import router
from services.mcp.metrics_api import get_metrics

app = FastAPI(title="CoFoundrAI")

app.include_router(router)

@app.get("/")
def root():
    return {"status": "CoFoundrAI backend running"}

@app.get("/mcp/metrics")
def mcp_metrics():
    return get_metrics()
