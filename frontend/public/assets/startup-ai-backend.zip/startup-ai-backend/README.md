# MCP- AN AI Startup Co-Founder Agent

## Project Description

AI Co-Founder Agent is a multi-agent AI system that helps analyze startup ideas and generate business insights automatically. The system uses multiple AI agents to evaluate startup ideas and produces structured analysis results.

The project integrates **Model Context Protocol (MCP)** to connect AI agents with external tools such as LinkedIn for real-time posting.

---

## Features

* Startup Idea Analysis
* Market Analysis
* Risk Analysis
* Business Strategy Generation
* Tech Stack Recommendation
* AI Generated Startup Image
* LinkedIn Post Generation
* Real-time LinkedIn Posting using MCP

---

## Technologies Used

**Backend**

* Python
* FastAPI
* MCP Architecture

**AI Models**

* Google Gemini API
* Groq API

**Frontend**

* React

**Integration**

* MCP
* Pipedream
* LinkedIn

---

## System Workflow

Idea Input → AI Agents → Analysis Results → Image Generation → LinkedIn Post

---

## Installation

### Install Dependencies

```
pip install -r requirements.txt
```

### Create Environment File

Create `.env` file:

```
GEMINI_API_KEY=your_key
GROQ_API_KEY=your_key
```

### Run Backend

```
uvicorn main:app --reload
```

Open:

```
http://127.0.0.1:8000/docs
```

---

## Main API Endpoints

### Analyze Idea

```
POST /analyze
```

Example:

```
{
 "idea":"AI Startup Mentor"
}
```

### Generate Report

```
POST /report
```

### Auto LinkedIn Post

```
POST /autopost
```

---

## Project Structure

```
agents/
services/
routers/
images/
reports/
main.py
requirements.txt
README.md
```

---
