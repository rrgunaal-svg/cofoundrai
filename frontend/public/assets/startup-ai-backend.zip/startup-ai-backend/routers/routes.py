from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from orchestrator.agent_manager import run_all_agents
from services.simulator import run_simulation
from services.pdf_service import generate_pdf
from services.image_generator import save_startup_brochure
from orchestrator.agent_manager import run_all_agents
from services.linkedin_post import generate_linkedin_post
from services.linkedin_auto import auto_linkedin_post
import logging

router = APIRouter()
logger = logging.getLogger("CoFoundrAI")


class IdeaRequest(BaseModel):
    idea: str


@router.post("/analyze")
def analyze(request: IdeaRequest):
    try:
        return run_all_agents(request.dict())   # ✅ FIXED
    except Exception as e:
        logger.exception("Analyze endpoint failed")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/simulate")
def simulate(data: dict):
    return run_simulation(data)


@router.post("/report")
def report(data: dict):

    file = generate_pdf(data)

    return {
        "report": file
    }

@router.post("/image")
def generate_image(data: dict):

    # Run agents to get analysis
    analysis = run_all_agents(data)

    # Generate elite brochure image
    file = save_startup_brochure({
        "idea": data["idea"],
        "analysis": analysis
    })

    return {
        "image_file": file
    }

@router.post("/linkedin")
def linkedin(data: dict):

    post = generate_linkedin_post(data)

    return {
        "post": post
    }

@router.post("/autopost")
def autopost(data: dict):

    return auto_linkedin_post(data)