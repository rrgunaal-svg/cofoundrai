import sqlite3
import json

def save_idea(idea, results):

    conn = sqlite3.connect("memory/cofoundr_memory.db")

    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ideas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            idea TEXT,
            results TEXT
        )
    """)

    cursor.execute(
        "INSERT INTO ideas (idea, results) VALUES (?, ?)",
        (idea, json.dumps(results))
    )

    conn.commit()
    conn.close()