
memory = []

def store(entry):
    memory.append(entry)

def fetch():
    return memory
