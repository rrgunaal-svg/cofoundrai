from services.llm_service import ask_llm
def run_market_agent(idea):

    prompt = f"""
Perform a detailed market analysis.

Startup Idea:
{idea}

Provide:

1. Target Customers
Describe main users and demographics.

2. Market Demand
Explain demand in detail.

3. Competition Analysis
Describe existing competitors.

4. Market Size
Explain TAM SAM SOM estimates.

5. Growth Opportunity
Explain future growth.

6. Market Trends
List at least 5 trends.

Write at least 400 words.
"""

    return ask_llm(prompt)