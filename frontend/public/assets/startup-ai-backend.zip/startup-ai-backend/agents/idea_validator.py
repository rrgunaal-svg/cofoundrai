from services.llm_service import ask_llm
def run_idea_agent(idea):

    prompt = f"""
Analyze the following startup idea in detail.

Startup Idea:
{idea}

Provide a detailed professional analysis including:

1. Executive Summary (Minimum 8 sentences)

2. Feasibility Analysis
Explain technical feasibility and implementation difficulty.

3. Uniqueness Analysis
Explain how unique this idea is compared to competitors.

4. Problem Solved
Describe what real-world problem this idea solves.

5. Strengths
List at least 5 strengths.

6. Weaknesses
List at least 5 weaknesses.

7. Final Verdict
Provide a professional evaluation paragraph.

Write at least 400 words.
"""

    return ask_llm(prompt)