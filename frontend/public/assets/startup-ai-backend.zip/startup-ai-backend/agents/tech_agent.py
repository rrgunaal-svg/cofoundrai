from services.llm_service import ask_llm
def run_tech_agent(idea):

    prompt = f"""
Recommend a complete technical architecture.

Startup Idea:
{idea}

Provide:

1. Frontend Technology

2. Backend Technology

3. Database

4. AI Models

5. Cloud Infrastructure

6. Security

7. Scalability

Explain each in detail.

Write at least 400 words.
"""

    return ask_llm(prompt)