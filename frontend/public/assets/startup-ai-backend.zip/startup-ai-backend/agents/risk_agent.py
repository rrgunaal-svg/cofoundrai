from services.llm_service import ask_llm
def run_risk_agent(idea):

    prompt = f"""
Analyze startup risks in detail.

Startup Idea:
{idea}

Provide:

1. Technical Risks
Explain development risks.

2. Financial Risks
Explain funding risks.

3. Market Risks
Explain competition risks.

4. Legal Risks
Explain legal challenges.

5. Operational Risks
Explain operational problems.

6. Risk Mitigation
Suggest solutions.

Write at least 400 words.
"""

    return ask_llm(prompt)