from services.llm_service import ask_llm
def run_business_agent(idea):

    prompt = f"""
Create a detailed business strategy.

Startup Idea:
{idea}

Provide:

1. Value Proposition

2. Revenue Model

3. Pricing Strategy

4. Customer Acquisition Strategy

5. Marketing Strategy

6. Growth Plan

7. Key Performance Indicators

Write at least 400 words.
"""

    return ask_llm(prompt)