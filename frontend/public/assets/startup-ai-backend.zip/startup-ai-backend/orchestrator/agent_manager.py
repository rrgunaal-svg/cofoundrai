import logging

from agents.idea_validator import run_idea_agent
from agents.market_agent import run_market_agent
from agents.risk_agent import run_risk_agent
from agents.business_agent import run_business_agent
from agents.tech_agent import run_tech_agent

from memory.sqlite_store import save_idea

logger = logging.getLogger("CoFoundrAI")


def run_all_agents(data: dict):

    logger.info("Starting multi-agent execution...")

    idea_text = data.get("idea", "")

    results = {

        "idea_validation": run_idea_agent(data),

        "market_analysis": run_market_agent(data),

        "risk_analysis": run_risk_agent(data),

        "business_strategy": run_business_agent(data),

        "tech_stack": run_tech_agent(data),

    }

    # Save idea + results into memory
    save_idea(idea_text, results)

    logger.info("Multi-agent execution completed")

    return results