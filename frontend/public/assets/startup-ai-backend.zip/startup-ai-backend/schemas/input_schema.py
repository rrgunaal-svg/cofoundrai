from pydantic import BaseModel, Field

class StartupIdea(BaseModel):
    idea: str = Field(..., description="Startup idea description")
    domain: str = Field(default="General", description="Domain of the startup")
    target_users: str = Field(default="General audience", description="Target customers")
    country: str = Field(default="Global", description="Target geography")
    budget: str = Field(default="Low", description="Budget level")
    stage: str = Field(default="Idea", description="Idea / MVP / Scaling")

class SimulationInput(BaseModel):
    scenario: str = Field(..., description="What-if scenario description")

class PitchRequest(BaseModel):
    startup_name: str
    tagline: str
    problem: str
    solution: str
